""""
Exercise 4
@Author : Eduardo Alarcón
@version: 1.0
"""
works = 0
num = 0
while not works:
    num = input('Enter the characters you want to check if there are a number: ')
    if num.isdigit():
        works = 1
    else:
        num = round(float(num))
        num = int(num)
print('The characters are a number. And the square of the number entered is', int(num)**2)
