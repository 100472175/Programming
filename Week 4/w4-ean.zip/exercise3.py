""""
Exercise 3: Relational operators
@Author : Eduardo Alarcón
@version: 1.0
"""

a = 3
b = 8
c = 3.0
r = a == 0
s = a != 0
t = a <= b
u = b >= a
v = b > a
w = b < a
x = c == 3.0
print("r:", r)
print("s:", s)
print("t:", t)
print("u:", u)
print("v:", v)
print("w:", w)
print("x:", x)
# The result of the program is
# r: False
# s: True
# t: True
# u: True
# v: True
# w: False
# x: True
# This happens because the == compares and if it is true, it assigns the variable with true or false
