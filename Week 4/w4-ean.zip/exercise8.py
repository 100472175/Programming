""""
Exercise 8: Is this a number?
@Author : Eduardo Alarcón
@version: 1.0
"""
numbers = '1234567890'
var1 = input('Press a key on the keyboard: ')
if var1 in numbers:
    print('The key pressed is  a number')
else:
    print('The key pressed is not a number')

