""""
Exercise 1: Assignment operators
@Author : Eduardo Alarcón
@version: 1.0
"""
a = 4
a += 2
print(a)
a -= 3
print(a)
a *= 3
print(a)
a /= 2
print(a)
a %= 4
print(a)
a == 0
print(a)
a //= 2
print(a)

# The operator += adds the value after the = to the variable
# The operator -= subtracts the number to the variable
# The *= operator multiplies the variable times the number that comes after
# The /= divides the number creating, if needed transforming the variable into boolean type
# The %= operator prompts the remainder from dividing the variable by the number
# The == operator reassigns the variable to whatever comes after the ==
# Lastly, the // operator discard the decimal part from a non-integer result division

