from mushrooms import Mushroom


class Powerups(Mushroom):
    def __init__(self, x: int, y: int):
        super().__init__(x, y)

