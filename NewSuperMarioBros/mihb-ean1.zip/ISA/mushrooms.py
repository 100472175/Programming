class Mushroom:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.sprite = (0, 16, 16, 16, 16, 12)

        self.tiles = [(0, 4), (1, 4), (0, 5), (1, 5)]
        

