from board import Board

Board(255, 255, 120, 200)
