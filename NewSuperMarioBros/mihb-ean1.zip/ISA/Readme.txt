Python 3.9 is required as well as Pyxel version 1.5.0
This is the versiona that has the collisions build up in the tile map and the collisions work
perfectly