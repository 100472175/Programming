Project created by María Isabel Hernández Barrio and Eduardo Alarcón Navarro
The version 1 is the one with tile map editing capabilities
The version 2 is the one that created the blocks with objects