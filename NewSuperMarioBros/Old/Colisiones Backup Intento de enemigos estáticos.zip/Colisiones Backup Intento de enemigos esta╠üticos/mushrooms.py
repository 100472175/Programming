import pyxel
class Mushroom:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        self.sprite = (0, 16, 16, 16, 16, 12)
        

