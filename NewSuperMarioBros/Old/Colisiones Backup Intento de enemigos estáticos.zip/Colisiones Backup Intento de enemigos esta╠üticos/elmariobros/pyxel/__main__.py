import pyxel

pyxel.cli()
