floor_list_of_isa = []
for i in range(144):
    floor_list_of_isa.append((i, 31))

for i in range(107):
    floor_list_of_isa.append((i + 148, 31))

print(floor_list_of_isa)