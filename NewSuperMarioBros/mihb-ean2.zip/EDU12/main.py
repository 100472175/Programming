from board import Board

# This importd the Board function and calls the whole program, with the parameters of the x and y dimensions of the
# screen and the number of frames per second the program will be running and lastly, the seconds you have to
# complete the level
Board(255, 255, 120, 300)
