Python 3.9 is required as well as Pyxel version 1.5.0
This is the versiona that has the collisions not working but the blocks are created by drawing each
Object individually and creating the mushrooms and coins from blocks. It creates the coins randomly.