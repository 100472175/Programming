song = 'Twinkle, twinkle, little star,\n \t how I wonder what you are! \n \t\t\tUp above the world so high, \n' \
       '\t\t\tlike a diamond in the sky.\nTwinkle, twinkle, little star, \n\thow I wonder what you are.'

print(song)
