#number: int
empty = None
action
print(empty)
print (action)
#"What happens is it gives out a NameError: name 'action' is not defined, because you asigned it an empty value"
#I didn't know if this is whaten from the exercice, so I also just entered a variable without doing anything else