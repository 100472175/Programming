a, b = "Manchorum ", "Locorum"
c = a+b
print(c)  # The variables join, one after the other
d = a-b
print(c)  # It prompts an error, specifically TypeError: unsupported operand type(s) for -: 'str' and 'str'
