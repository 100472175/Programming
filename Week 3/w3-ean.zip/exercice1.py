integer = 100
floating_point = 3.14
boolean = True
string ="The class action suit you prepared last night, scrap it and create a new one"
z = complex(5,3)

print("The integer value is ", integer)
print("The floating point variable is: ", floating_point)
print("The boolean has a state", boolean, ", from 1/True or 0/False")
print("The string is:", string)
print("The complex number is ", z)