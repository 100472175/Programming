a = 2.71828
b = a
print(b)
a = "Changed variable"
print(b)  # The first variable is not changed as the ssignation is done before the value of the variable changes
