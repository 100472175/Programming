a, b = 5, 10
c = a/b
print(c)  # No, there isn't any error, as the variables in python can change its type. The result would not change
# if the variable was declared as a float because the variables in python can change their type
