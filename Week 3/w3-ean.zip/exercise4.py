variable:int = 10
# I declared an integer variable and assigned a value of 10.
variable = "hello"
# This is called Dynamic Type. It is not recommended but possible

