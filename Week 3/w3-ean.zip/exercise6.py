a,b,c = 10, 2.71828, "hello"
#Yes, this is posible, as you can assign different types of variables to different variables in a same line.
print(a,b,c)
