variable = 10
print(variable)
# I declared the variable and assigned it a value of 10
variable = 3.14
print(variable)
# I changed the value of the variable. It is possible and allowed in python. The type of variable does not affect the
# ability to change it's content, you can input a string and then change it to an integer, but it is not recommended.
