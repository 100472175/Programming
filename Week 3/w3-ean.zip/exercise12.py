name = 'Johnny Depp'
age = 55
height = 1.78
weight = 65.4
eyes = 'brown'
hair = 'brown'
print("Let’s talk about", name)
print("He's", age, "years old")
print("He’s", height, "f meters tall.")
print("He’s", weight, "kilograms heavy.")
print("Actually that’s not too heavy.")
print("He has ", eyes, " eyes and ", hair, " hair.")