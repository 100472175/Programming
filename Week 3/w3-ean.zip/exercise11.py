s = 'Twinkle, twinkle, little star,\n \t how I wonder what you are! \n \t\t\tUp above the world so high, \n' \
       '\t\t\tlike a diamond in the sky.\nTwinkle, twinkle, little star, \n\thow I wonder what you are.'

#print(song)
first_part = s[:30]
second_part = s[66:92]
third_part = s[-22:-1]

print(first_part)
print(second_part)
print(third_part)