a: float = 1e300
b: float = 1e300
float(a)
float(b)

print(a)
print(b)
c = a * b
float(c)
print(c) #The result is inf

d = a ** b
print(d) # The result of doing this operation is OverflowError
